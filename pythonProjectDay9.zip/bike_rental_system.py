"""
A bike rental system

customers, rental shop

available bikes ( type & no.of bikes )
price
datetime

rental shop
display availble inventory
take requests on hourly, daily and weekly basis based on the available stock
invoice when the customer returns the bike

"""
import datetime
class BikeRental:
    def __init__(self,num_of_available_vehicles=0):
        self.num_of_available_vehicles = num_of_available_vehicles

    def display_inventory(self):
        print(f"There is currently {self.num_of_available_vehicles} bikes available for rent")
        return self.num_of_available_vehicles

    #hourly, weekly, daily basis
    def rentBikeOnHourlyBasis(self,n):
        """
        return a bike on hourly basis to a customer

        :param n: customer requests - number of bikes requested by the customer
        :return:
        """

        if n <= 0:
            print("Invalid Request. Number of bikes should be positive")

        #out of stock
        elif n > self.num_of_available_vehicles:
            print(f"Number of vehicles available is {self.num_of_available_vehicles} and the requested bikes are {n} which is higher")

        else:
            now = datetime.datetime.now()
            print(f"you have rented a {n} bike(s) on hourly basis today at {now.hour} hours")
            print(f"you will be charged with $20 for each hour per bike")
            print("we hope that you enjoy our service")

            self.num_of_available_vehicles = self.num_of_available_vehicles - n
            return now

    def rentBikeOnDailyBasis(self,n):
        """
        return a bike on daily basis to a customer

        :param n: customer requests - number of bikes requested by the customer
        :return:
        """

        if n <= 0:
            print("Invalid Request. Number of bikes should be positive")

        #out of stock
        elif n > self.num_of_available_vehicles:
            print(f"Number of vehicles available is {self.num_of_available_vehicles} and the requested bikes are {n} which is higher")

        else:
            now = datetime.datetime.now()
            print(f"you have rented a {n} bike(s) on daily basis today at {now.hour} hours")
            print(f"you will be charged with $40 for each hour per bike")
            print("we hope that you enjoy our service")

            self.num_of_available_vehicles = self.num_of_available_vehicles - n
            return now

    def rentBikeOnWeeklyBasis(self,n):
        """
        return a bike on weekly basis to a customer

        :param n: customer requests - number of bikes requested by the customer
        :return:
        """

        if n <= 0:
            print("Invalid Request. Number of bikes should be positive")

        #out of stock
        elif n > self.num_of_available_vehicles:
            print(f"Number of vehicles available is {self.num_of_available_vehicles} and the requested bikes are {n} which is higher")

        else:
            now = datetime.datetime.now()
            print(f"you have rented a {n} bike(s) on weekly basis today at {now.hour} hours")
            print(f"you will be charged with $80 for each hour per bike")
            print("we hope that you enjoy our service")

            self.num_of_available_vehicles = self.num_of_available_vehicles - n
            return now

        #### billing
    def returnBike(self,request):
        """
        1. Accept a rented bike from the customer
        2. update the stock
        3. return a bill
        """
        rentalTime,rentalBasis,numofBikes = request
        if rentalTime and rentalBasis and numofBikes:
            self.num_of_available_vehicles += numofBikes
            now = datetime.datetime.now()
            rentalPeriod = now - rentalTime

            #hourly - 1, #daily - 2, #weekly - 3
            if rentalBasis == 1:
                bill = round(rentalPeriod.seconds/3600) * 20 * numofBikes

            elif rentalBasis == 2:
                bill = round(rentalPeriod.days) * 40 * numofBikes

            elif rentalBasis == 3:
                bill = round(rentalPeriod.days / 7) * 80 * numofBikes # 3 days, week

            if (numofBikes >= 3 and numofBikes <= 6):
                print("you are eligible for the discount of 30% discount")
                bill = bill * 0.7

            print(f"Thanks for enjoying our service, your bill is {bill}")
            return bill
        else:
            print("Did the bike rented with us?")
            return None

class Customer:

    def __init__(self):
        self.bikes = 0
        self.rentalBasis = 0
        self.rentalTime = 0
        self.bill = 0

    #request, return
    def requestBike(self):
        """
        Takes a request from the customer for the number of bikes
        :return:
        """
        bikes = input("how many bikes would you like to rent?")
        try:
            bikes = int(bikes)
        except ValueError:
            print("That's not a positive integer")
            return -1

        if bikes < 1:
            print("Invalid Input. Number of bikes should be greater than zero.")
        else:
            self.bikes = bikes
        return self.bikes

    def returnBike(self):
        """
        Allow customers to retunr their bikes to the rental shop
        :return:
        """
        if self.rentalBasis and self.rentalTime and self.bikes:
            return self.rentalTime, self.rentalBasis, self.bikes
        else:
            return 0,0,0

shop = BikeRental(100)
customer = Customer()
while True:
    print("""
    1.Display Available bikes
    2.Request a bike on hourly basis $20
    3.Request a bike on daily basis $40
    4.Request a bike on weekly basis $80
    5.Return a bike
    6.Exit
    """)

    choice = input("Enter choice: ")

    try:
        choice = int(choice)
    except ValueError:
        print("That's not an integer")
        continue

    if choice == 1:
        shop.display_inventory()

    elif choice == 2:
        customer.rentalTime = shop.rentBikeOnHourlyBasis(customer.requestBike())
        customer.rentalBasis = 1

    elif choice == 3:
        customer.rentalTime = shop.rentBikeOnDailyBasis(customer.requestBike())
        customer.rentalBasis = 2

    elif choice == 4:
        customer.rentalTime = shop.rentBikeOnWeeklyBasis(customer.requestBike())
        customer.rentalBasis = 3

    elif choice == 5:
        customer.bill = shop.returnBike(customer.returnBike())
        customer.rentalBasis, customer.rentalTime, customer.bikes = 0,0,0

    elif choice == 6:
        break

    else:
        print("Invalid Input. Choose Choice between 1 to 6")

    print("Thank you for enjoying our service")





